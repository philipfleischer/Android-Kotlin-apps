package no.uio.ifi.in2000.philipef.oblig2.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import no.uio.ifi.in2000.philipef.oblig2.data.alpacas.AlpacaPartiesRepository
import no.uio.ifi.in2000.philipef.oblig2.data.votes.VotesRepository
import no.uio.ifi.in2000.philipef.oblig2.model.alpacas.PartyInfo
import no.uio.ifi.in2000.philipef.oblig2.model.votes.District

sealed interface AlpacaPartyUiState {
    data class Success(
        val alpacas: List<PartyInfo>,
        val selectedDistrict: District = District.DISTRICT_1,
        val votes: Map<String, Int> = emptyMap()
    ) : AlpacaPartyUiState

    data object Error : AlpacaPartyUiState
    data object Loading : AlpacaPartyUiState
}

class HomeViewModel(
    private val alpacaPartiesRepository: AlpacaPartiesRepository,
    private val votesRepository: VotesRepository
) : ViewModel() {

    var alpacaPartyUiState: AlpacaPartyUiState by mutableStateOf(AlpacaPartyUiState.Loading)
        private set

    init {
        getAlpacas()
    }

    fun getAlpacas() {
        viewModelScope.launch {
            alpacaPartyUiState = AlpacaPartyUiState.Loading
            alpacaPartyUiState = try {
                AlpacaPartyUiState.Success(alpacaPartiesRepository.getAlpacas()).also {
                    selectDistrict(it.selectedDistrict)
                }
            } catch (e: Exception) {
                AlpacaPartyUiState.Error
            }
        }
    }

    fun selectDistrict(district: District) {
        viewModelScope.launch {
//            val votes = votesRepository.getVotesForDistrict(district)
//                .associate { it.alpacaPartyId to it.numberOfVotesForParty }

            val votes = alpacaPartiesRepository.getVotesWithNamesForDistrict(district)

            val current = alpacaPartyUiState
            if (current is AlpacaPartyUiState.Success) {
                alpacaPartyUiState = current.copy(
                    selectedDistrict = district,
                    votes = votes
                )
            }
        }
    }
}

