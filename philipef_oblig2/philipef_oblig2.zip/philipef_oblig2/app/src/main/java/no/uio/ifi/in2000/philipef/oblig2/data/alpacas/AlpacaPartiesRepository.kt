package no.uio.ifi.in2000.philipef.oblig2.data.alpacas

import no.uio.ifi.in2000.philipef.oblig2.data.votes.VotesRepository
import no.uio.ifi.in2000.philipef.oblig2.model.alpacas.PartyInfo
import no.uio.ifi.in2000.philipef.oblig2.model.votes.District

interface AlpacaPartiesRepository {
    suspend fun getAlpacas(): List<PartyInfo>
    suspend fun getPartyById(id: String): PartyInfo?
    suspend fun getVotesWithNamesForDistrict(district: District): Map<String, Int>
}

class DefaultAlpacasRepository(
    private val dataSource: AlpacaPartiesDataSource,
    private val votesRepository: VotesRepository
) : AlpacaPartiesRepository {

    override suspend fun getAlpacas() = dataSource.fetchParties()

    override suspend fun getPartyById(id: String) =
        dataSource.fetchParties().find { it.id == id }

    override suspend fun getVotesWithNamesForDistrict(district: District): Map<String, Int> {
        val votes = votesRepository.getVotesForDistrict(district) // List<DistrictVotes>

        return votes.associate { v -> v.alpacaPartyId to v.numberOfVotesForParty }
    }
}



